def foo():
    print("foo")

# foo()
